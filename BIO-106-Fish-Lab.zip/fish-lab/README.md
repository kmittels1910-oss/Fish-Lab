# BIO 106 | Inside a bony fish

A browser-based comparative dissection with seven stations and 29 structure checks. Students start with an intact yellow croaker, open the abdomen, retract layers, and compare the deep anatomy with a gill close-up and a male yellow perch. The layer controls transition between real photographs. They do not represent a continuous recording or a single specimen throughout.

Canvas: Add the published lab URL as a **Modules → + → External URL** item, with **Load in a new tab** selected. Test it in Student View. For an embedded Canvas Page, use the optional HTML fragment in [canvas-entry.html](canvas-entry.html) and retain the direct-link fallback.

Progress stays in the student's browser. If you need an assignment submission, ask students to submit their debrief answers and, if useful, their copied progress summary in Canvas. The summary is a self-reported record; this lab does not authenticate students or send grades.

Open [index.html](index.html) for local review. No build, backend, or third-party JavaScript is required. The photo assets and anatomy credits are included in the lab. Coordinate regions in anatomy.js use percentages of the un-cropped photo; edit them together with any photo crop or replacement.
